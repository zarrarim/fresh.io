function loadFrame(url, title) {
  const iframe = document.getElementById('snowRiderFrame');
  iframe.style.display = 'block';
  iframe.src = url;
  document.getElementById('subtitle').style.display = 'none';
}

function loadSnowRider() {
  const iframe = document.getElementById('snowRiderFrame');
  iframe.style.display = 'block';
  iframe.src = 'https://snow-rider-3d-pi.vercel.app';
  document.getElementById('subtitle').style.display = 'block';
}

function fullscreenSnowRider(href) {
  const iframe = document.getElementById('snowRiderFrame');
  const stl = iframe.style;
  stl.border = stl.outline = 'none';
  stl.width = '100vw';
  stl.height = '100vh';
  stl.position = 'fixed';
  stl.left = stl.right = stl.top = stl.bottom = '0';
  iframe.src = href;
}

document.addEventListener("keydown", async (e) => {
  if (e.key === "`") window.parent.window.location.replace("https://google.com/");
});